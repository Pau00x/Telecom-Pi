import I2C_LCD_driver
import sys

from time import *

class my_lcd():

    def __init__(self):

        self.mylcd = I2C_LCD_driver.lcd()

    def display(self, msg, y, x):
        # ~ for x in range(len(msg)):
            self.mylcd.lcd_display_string(msg.replace("\n", ""), y, x)
            
    def clear(self): 
        self.mylcd.lcd_clear()
    
# ~ def main():
    # ~ lcd = my_lcd()
    # ~ msg = sys.stdin.readlines()
    # ~ lcd.display(msg)

# ~ if __name__ == "__main__":
    # ~ main()

